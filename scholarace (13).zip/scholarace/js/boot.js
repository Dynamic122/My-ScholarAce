/* Start-up: load settings + session, register routes, render. */
(async function () {
  const A = window.App, P = A.pages;

  A.route('/', P.landing);
  A.route('/login', P.login, { guest: true });
  A.route('/register', P.register, { guest: true });
  A.route('/about', P.about);
  A.route('/contact', P.contact);
  A.route('/terms', P.terms);
  A.route('/privacy', P.privacy);
  A.route('/premium', P.premium);
  A.route('/dashboard', P.dashboard, { auth: true });
  A.route('/start', P.start, { auth: true });
  A.route('/history', P.history, { auth: true });
  A.route('/result/:id', P.result, { auth: true });
  A.route('/exam/:id', P.exam, { auth: true });
  A.route('/library', P.library, { auth: true });
  A.route('/verify/:token', P.verifyLink);
  A.route('/activate/:token', P.activate, { auth: true });

  A.cfg = await A.api('GET', '/config');
  document.title = A.cfg.brand + ' | JAMB mock exams';
  if (!A.cfg.storageOk) A.toast('Your browser is not saving data (private window?). ScholarAce works, but your account will be lost when you close this tab.', 'error');

  if (A.token) {
    try { A.user = (await A.api('GET', '/auth/me')).user; } catch (_) { A.setSession(null, null); }
  }
  if (A.user && (!location.hash || location.hash === '#/')) location.hash = '#/dashboard';
  A.render();

  // Lets the site open on weak networks (only works when hosted, not from a local file)
  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }
})();
